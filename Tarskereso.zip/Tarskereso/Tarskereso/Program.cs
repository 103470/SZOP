﻿using System.Net.Sockets;
using System.Xml.Linq;

namespace Szerver
{
    internal class Program
    {
        static void Main(string[] args)
        {
            XDocument userXml = XDocument.Load("users.xml");
            foreach(XElement user in userXml.Descendants("user")){
                Console.WriteLine(user);
                ClientManager.Users.Add(new User(user.Attribute("username").Value, user.Attribute("password").Value));
            }

            XDocument datesXml = XDocument.Load("dates.xml");
            foreach (XElement date in datesXml.Descendants("date"))
            {
                Console.WriteLine(date);
                ClientManager.Dates.Add(new Randi(
                    ClientManager.Users.Find(u => u.Username == date.Attribute("user1").Value),
                    ClientManager.Users.Find(u => u.Username == date.Attribute("user2").Value),
                    date.Attribute("subject").Value,
                    Enum.Parse<DateStatus>(date.Attribute("status").Value)
                    ));
            }
            TcpListener listener = new TcpListener(8923);
            listener.Start();

            while(true)
            {
                TcpClient client = listener.AcceptTcpClient();
                Thread theard = new Thread(() => ClientManager.ServerClient(client));
                theard.Start();
            }

            listener.Stop();
        }
    }
}