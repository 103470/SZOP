﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Szerver
{

    internal enum DateStatus { pending, accepted, rejected}
    internal class Randi
    {
        public User User1 { get; private set; }
        public User User2 { get; private set; }
        public string Subject { get; private set; }
        public DateStatus Status { get; private set; }

        public Randi(User user1, User user2, string subject, DateStatus status)
        {
            User1 = user1;
            User2 = user2;
            Subject = subject;
            Status = status;
        }
    }
}
