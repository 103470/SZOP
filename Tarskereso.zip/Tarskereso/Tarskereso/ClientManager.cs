﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Szerver
{
    internal class ClientManager
    {
        static public List<User> Users = new List<User>();
        static public List<Randi> Dates = new List<Randi>();
        

        static User Login(string username, string password)
        {
            return Users.Find(u => u.Username == username && u.Password == password);
        }

        static bool Invite(User user1, string username, string subject) {
            if (Dates.Exists(d => d.User1 == user1 && d.User2.Username == username))
                return false;
            Dates.Add(new Randi(user1, Users.Find(u => u.Username == username)
                , subject, DateStatus.pending));
            return true;


            
        }
        static internal void ServerClient(TcpClient tcpClient)
        {
            StreamReader reader = new StreamReader(tcpClient.GetStream());
            StreamWriter writer = new StreamWriter(tcpClient.GetStream());

            User loggedInUser = null;
            
            while(!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                string[] data = line.Split('|');
                switch(data[0]){
                    case "LOGIN":
                        if(data.Length != 3)
                        {
                            writer.WriteLine("HIBA: LOGIN 2 paramétert vár (Username, Pasword)");
                            break;
                        }
                        if (loggedInUser != null)
                        {
                            writer.WriteLine("HIBA: LOGIN nem sikerüt, mert valaki már be van lépve");
                            break;
                        }
                        loggedInUser = Login(data[1], data[2]);
                        if(loggedInUser == null)
                        {
                            writer.WriteLine("HIBA: LOGIN nem sikerüt a megadott username-el és jelszóval");
                            break;
                        }


                        break;
                    case "LOGOUT":
                        loggedInUser = null;
                        break;
                    case "EXIT":
                        reader.Close();
                        writer.Close();
                        Console.WriteLine($"Kilépett egy kliens");
                        break;
                    case "INVITE":
                        if (data.Length != 3)
                        {
                            writer.WriteLine("HIBA: LOGIN 2 paramétert vár (Username, Pasword)");
                            break;
                        }
                        if(loggedInUser == null)
                        {
                            writer.WriteLine("HIBA: Invite-hoz be kell jelentkezni!");
                            break;
                        }
                        if (Invite(loggedInUser, data[1], data[2]))
                        {
                            writer.WriteLine("Invite sikerült!");
                           
                        }
                        else
                        {
                            writer.WriteLine("HIBA: Invite nem sikerült!");
                        }

                        break;
                    case "ACCEPT":
                        break;
                    case "REJECT":
                        break;
                    case "INVITATIONS":
                        break;
                    default:
                        Console.WriteLine($"Érvénytelen utasítás : {data[0]}");
                        writer.WriteLine($"Érvénytelen utasítás : {data[0]}");
                        break;
                }



                
            }
        }
    }
}
