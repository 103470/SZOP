﻿using System.Net.Sockets;

namespace Client
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string serverIP = "127.0.0.1";
            int serverPort = 8923;

            TcpClient tcpClient = new TcpClient(serverIP, serverPort);

            StreamReader reader = new StreamReader(tcpClient.GetStream());
            StreamWriter writer = new StreamWriter(tcpClient.GetStream());

            Console.WriteLine("Type your commands!");
            while (true) {
                string command = Console.ReadLine();

                writer.WriteLine(command);
                writer.Flush();

                string response = reader.ReadLine();

                if(response == "BEGIN")
                {
                    // "END"-ig olvasni és megjeleníteni a beérkezett sorokat
                }
                else
                {
                    Console.WriteLine(response);
                }
            }

            reader.Close();
            writer.Close();



        }
    }
}